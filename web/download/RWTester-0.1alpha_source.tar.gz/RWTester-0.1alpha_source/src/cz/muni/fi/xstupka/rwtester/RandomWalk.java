// File: RandomWalk.java
// Doc language: Czech

package cz.muni.fi.xstupka.rwtester;

import cz.muni.fi.xstupka.rwtester.graph.Graph;
import cz.muni.fi.xstupka.rwtester.graph.GraphException;
import cz.muni.fi.xstupka.rwtester.graph.Vertex;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * Abstraktni trida reprezentujici nahodnou prochazku.
 * Trida je predkem pro <code>DirectedRandomWalk</code> realizujici nahodnou
 * prochazku na orientovanych grafech a pro <code>UndirectedRandomWalk</code>
 * realizujici nahodnou prochazku na neorientovancyh grafech.
 *
 * @author Pavel Stupka &lt;xstupka@fi.muni.cz&gt;
 */
public abstract class RandomWalk {

    // definice nekonecna
    public static final long INFINITY = -1;
    
    // cas prubezneho vypisu prubehu nahodne prochazky
    public static final long DEFAULT_VERBOSE_TIME = 1000000;

    private boolean verbose;
    private long verboseTime;
    
    private Graph graph;
    protected Random random;
    protected long time;
    protected int vertices;
    protected int visitedVertices;
    protected long[] percentageCover;
    protected String type;
    protected int run;

    /**
     * Vytvori novou instanci tridy RandomWalk
     *
     * @param graph graf, ktery ma byt pro nahodnou prochazku pouzit
     * @throws NullPointerException pokud je parametr <code>graph</code> null
     */
    public RandomWalk(Graph graph) {
        if (graph == null) {
            throw new NullPointerException();
        }
        this.graph = graph;
        vertices = graph.getNumberOfVertices();
        random = new Random();
        random.setSeed(hashCode() + System.nanoTime());
        percentageCover = new long[101];
        setVerbose(false);
        setVerboseTime(DEFAULT_VERBOSE_TIME);
    }
    
    /**
     * Vraci celkovy cas, ktery byl potreba pro realizaci nahodne prochazky
     *
     * @return celkovy cas, ktery byl potreba pro realizaci nahodne prochazky
     */
    public long getTime() {
        return time;
    }

    /**
     * Vraci procentualni pokryti grafu.
     *
     * @return seznam dlouhy 101 prvku (indexy 0 .. 100), kde index udava procentualni
     *     pokryti grafu a hodnota daneho indexu pak cas, ve kterem bylo tohoto pokryti
     *     dosazeno
     */
    public long[] getPercentageCover() {
        return percentageCover;
    }

    /**
     * Spousti nahodnou prochazku pro pokryti grafu.
     * Mod pokryti grafu znamena, ze nahodna prochazka bude aktivni do te doby,
     * nez bude aspon jednou navstiven urcity pocet vrcholu. Procentualni pokryti
     * pak urcuje tuto hranici zastaveni nahodne prochazky.
     *
     * @param startVertex pocatecni vrchol, ze ktereho ma byt nahodna prochazka spustena
     * @param coverage procentualni pokryti, ktere ma byt dosazeno (v procentech)
     * @throws GraphException pokud vrchol zadaneho jmena v grafu neexistuje
     */
    public abstract void runCover(String startVertex, int coverage) throws GraphException;

    /**
     * Spousti nahodnou prochazku k nalezeni cesty k zadanemu vrcholu.
     * Princip tohoto modu nahodne prochazky spociva v tom, ze nahodna prochazka je
     * aktivni do te doby, nez je objeven zadany cilovy vrchol.
     *
     * @param startVertex pocatecni vrchol, ze ktereho ma byt nahodna prochazka spustena
     * @param endVertex koncovy vrchol, ktereho ma nahodna prochazka dosahnout
     * @throws GraphException pokud aspon jeden z vrcholu zadaneho jmena v grafu neexistuje
     */
    public abstract void runFindPath(String startVertex, String endVertex) throws GraphException;

    /**
     * Inicializuje grap pred spustenim algoritmu
     */
    protected void initGraph() {
        Collection<Vertex> vertices = getGraph().getVertices();
        for (Vertex v : vertices) {
            v.setValueA(0);          // pocet navstiveni
            v.setValueB(INFINITY);   // cas prvniho pristupu
            v.setParent(null);       // predek vrcholu
        }
        visitedVertices = 0;
        time = 0;
        random.setSeed(hashCode() + System.nanoTime());
        for (int p = 0; p < 101; p++) {
            percentageCover[p] = 0;
        }
        run = 1;
    }
    
    /**
     * Tato metoda vraci nahodneho naslednika vrcholu
     *
     * @param u vrchol, jehoz nahodneho naslednika chceme ziskat
     * @return nahodny naslednik zadaneho vrcholu nebo null v pripade, ze zadny
     *     nasledni neexistuje
     */
    protected Vertex getRandomNeighbour(Vertex u) {
        if (u.getNumberOfNeighbours() == 0) {
            return null;
        }
        List<Vertex> list = u.getNeighbours();
        if (list == null) {
            return null;
        }
        int rnd = random.nextInt(u.getNumberOfNeighbours());
        return list.get(rnd);
    }

    /**
     * Vraci informace o tom, zda-li je aktivni rezim vypisu nahodne prochazky
     * 
     * @return informace o tom, zda-li je aktivni rezim vypisu nahodne prochazky
     */
    public boolean isVerbose() {
        return verbose;
    }

    /**
     * Nastavuje rezim vypisu nahodne prochazky
     *
     * @param verbose ma-li byt rezim vypisu aktivni ci nikoli
     */
    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    /**
     * Vraci interval vypisu nahodne prochazky
     * 
     * @return interval vypisu nahodne prochazky
     */
    public long getVerboseTime() {
        return verboseTime;
    }

    /**
     * Nastavuje interval vypisu nahodne prochazky (implicitni je DEFAULT_VERBOSE_TIME)
     *
     * @param verboseTime interval vypisu nahodne prochazky
     */
    public void setVerboseTime(long verboseTime) {
        this.verboseTime = verboseTime;
    }

    /**
     * Vraci graf prirazeny teto nahodne prochazce
     *
     * @return graf prirazeny teto nahodne prochazce
     */
    public Graph getGraph() {
        return graph;
    }
}
