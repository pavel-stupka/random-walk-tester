package cz.muni.fi.xstupka.rwtester.graph;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * This class generates a random graph.
 * Parameters for generating the graph are number of vertices and the degree.
 * New vertex is added to the graph and is randomly connected to other m 
 * vertices. If there are at least m other vertices the variable m equals the 
 * degree, otherwise it equals the number of other vertices.
 *
 * @author Pavel Stupka &lt;xstupka@fi.muni.cz&gt;
 */
public class ScaleFreeGraphGenerator implements GraphFactory {
    
    private Map<Integer, Vertex> map;
    private Random random;
    
    /**
     * Creates a new instance of RandomGraphGenerator.
     *
     * @param vertices number of vertices that should be generated
     * @param connect initial degree of the new vertex
     * @throws IllegalArgumentException if a negative parametr is given
     */
    public ScaleFreeGraphGenerator(int vertices, int connect) {
        if (vertices < 0 || connect < 0) {
            throw new IllegalArgumentException("negative parameter");
        }

        map = new HashMap<Integer, Vertex>();
        random = new Random();
        random.setSeed(hashCode() + System.nanoTime());

        for (int p = 0; p < vertices; p++) {
            Vertex vertex = new Vertex(p + "");
            
            try {
                if (p == 0) {
                    // let's add first vertex
                } else {
                    int i = connect;
                    if (p < i) i = p;
                    int []num = generateUniqueNumbers(i, p);
                    for (int q = 0; q < i; q++) {
                        Vertex a = map.get(num[q]);
                        a.addNeighbour(vertex);
                        vertex.addNeighbour(a);
                    }
                }       
            } catch (VertexException ex) {
                // OK - this exeption will never be thrown
                ex.printStackTrace();
            }
            map.put(p, vertex);
        }
    }

    /**
     * Returns a generated graph.
     * @return generated graph
     */
    public Graph getGraph() {
        return new GraphImpl((Collection<Vertex>) map.values(), false, false);
    }
    
    /**
     * Generates m unique numbers from 0 to size-1.
     * We assume taht size >= m !!!
     */
    private int[] generateUniqueNumbers(int m, int size) {
        int []numbers = new int[m];        
        
        for (int p = 0; p < m; p++) {            
            boolean done = true;
            int i;            
            do {
                i = random.nextInt(size);
                done = true;
                for (int q = 0; q < p; q++) {
                    if (numbers[q] == i) {
                        done = false;
                    }
                }
            } while(!done);
            numbers[p] = i;
        }

        return numbers;
    }
}

