#!/bin/sh

DATA_INSTALL_DIR="/ChartGenerator"
BIN_INSTALL_DIR="/bin"
USER=`whoami`

# set root / user installation
if [ $USER = "root" ]; then
    INSTALL_DIR="/usr/local"
else
    INSTALL_DIR="$HOME"
fi

echo
echo "ChartGenerator version 0.3 Installation"
echo
echo "running as $USER"
echo "installing to $INSTALL_DIR"

# check for data install bin
if [ ! -d "$INSTALL_DIR$DATA_INSTALL_DIR" ]; then
    if ! mkdir "$INSTALL_DIR$DATA_INSTALL_DIR" >&/dev/null; then
        echo
        echo "Can't create $INSTALL_DIR$DATA_INSTALL_DIR" 2>&1
        echo
        exit 1
    fi
fi

#check for bin install dir
if [ ! -d "$INSTALL_DIR$BIN_INSTALL_DIR" ]; then
    if ! mkdir "$INSTALL_DIR$BIN_INSTALL_DIR" >&/dev/null; then
        echo
        echo "Can't create $INSTALL_DIR$BIN_INSTALL_DIR" 2>&1
        echo
        exit 1
    fi
fi

# copy program files
cp "ChartGenerator.jar" "$INSTALL_DIR$DATA_INSTALL_DIR/"
cp -r "lib" "$INSTALL_DIR$DATA_INSTALL_DIR/"

# Create an executable file 'chartgen'
echo "#!/bin/sh" >"$INSTALL_DIR$BIN_INSTALL_DIR/chartgen"
echo -n "java -jar $INSTALL_DIR$DATA_INSTALL_DIR/ChartGenerator.jar"\
>>"$INSTALL_DIR$BIN_INSTALL_DIR/chartgen"
echo ' "$@"' >>"$INSTALL_DIR$BIN_INSTALL_DIR/chartgen"
chmod u+x "$INSTALL_DIR$BIN_INSTALL_DIR/chartgen"

echo "DONE"
echo
echo "type 'chartgen' to run the program"
echo
